package com.test;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.Assert.assertEquals;

import java.util.List;
import java.util.NoSuchElementException;


import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.dao.EmptyResultDataAccessException;

import com.test.model.Notepad;
import com.test.model.Pad;
import com.test.service.NotepadService;
import com.test.service.PadService;

@SpringBootTest
class NoteApplicationTests {

	@Autowired 
	private NotepadService use;
	@Autowired
	private PadService use1;
	
	@Test
	void contextLoads() {

	}
	@Test
	public void gettestId() {
		assertEquals(1,1);
	}

	@Test 
	void gettest()  throws Exception{
		Notepad note =new Notepad(1,"nothing","low", null);
		Notepad note1 =new Notepad(2,"work","HIGH",null);
		Notepad note3=new Notepad(3,"nothing","VERYHIGH",null);
		use.save(note);
		use.save(note1);
		use.save(note3);
		Notepad u= use.get(1);
		assertThat(u).isNotNull();
	}
	@Test 
	void gettest1()  throws Exception{
		Pad pad =new Pad(1,"head","content");
		Pad pad1 =new Pad(2,"work","HIGH");
		Pad pad2=new Pad(3,"nothing","VERYHIGH");
		use1.save(pad);
		use1.save(pad1);
		use1.save(pad2);
		Pad u1= use1.get(1);
		assertThat(u1).isNotNull();
	}
	
	@Test
	void listaltest() {
		List<Notepad> act=use.listAll();
		assertThat(act).isNotNull();
	}
	@Test
	void listaltest1() {
		List<Pad> act1=use1.listAll();
		assertThat(act1).isNotNull();
	}
	@Test
	void updatetest() {
		Notepad notee =new Notepad(3,"namey","password",null);
		use.update(notee);
		assertThat(notee).isNotNull();		
		
	}
	
	@Test
	void updatetest1() {
		Pad pad1 =new Pad(3,"nothing","VERYHIGH");
		use1.update(pad1);
		assertThat(pad1).isNotNull();		
		
	}
	
	@Test 
	void deletetest() throws Exception{
	
		  try{
				use.delete(1);
				use.delete(2);
				use.delete(3);
	            use.listAll();
	            System.out.println("Items Still Exist");
	        }
	        catch(EmptyResultDataAccessException e){
	            System.out.println("Done");
	        }
	}
	


}
