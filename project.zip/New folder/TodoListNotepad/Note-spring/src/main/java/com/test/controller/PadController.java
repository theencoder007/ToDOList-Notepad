package com.test.controller;

import java.util.List;
import java.util.NoSuchElementException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.test.model.Pad;
import com.test.service.PadService;

@RestController
@CrossOrigin("*")
@RequestMapping("/")
public class PadController {
	@Autowired
	private PadService padservice;
	
	@GetMapping("pad")
	public List<Pad> list(){
		return padservice.listAll();
	}
	
	@GetMapping("pad/{id}")
	public ResponseEntity<Pad> get(@PathVariable Integer id){
		try {
			Pad pad =padservice.get(id);
			return new ResponseEntity<Pad>(pad,HttpStatus.OK);
		}catch (NoSuchElementException e){
            return new ResponseEntity<Pad>(HttpStatus.NOT_FOUND);
		}
	}
		@PostMapping("pad")
	    public ResponseEntity<Pad> add(@RequestBody Pad pad){
	        padservice.save(pad);
	        return new ResponseEntity<Pad>(pad,HttpStatus.CREATED);
	    }

	    @PutMapping("pad")
	    public ResponseEntity<?> update(@RequestBody Pad pad) {
	        try {
	            Pad existPad = padservice.update(pad);
	            padservice.save(pad);
	            return new ResponseEntity<>(HttpStatus.OK);
	        } catch (NoSuchElementException e) {
	            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
	        }
	    }

	    @DeleteMapping("pad/{id}")
	    public void delete(@PathVariable Integer id) {
	        padservice.delete(id);
	    }


	}

