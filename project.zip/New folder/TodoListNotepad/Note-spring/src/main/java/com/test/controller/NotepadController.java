package com.test.controller;

import java.util.List;
import java.util.NoSuchElementException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.test.model.Notepad;
import com.test.service.NotepadService;

@RestController
@CrossOrigin("*")
@RequestMapping("/")
public class NotepadController {

	@Autowired
	private NotepadService noteservice;
	
	@GetMapping("notepad")
	public List<Notepad> list(){
		return noteservice.listAll();
	}
	
	@GetMapping("notepad/{id}")
	public ResponseEntity<Notepad> get(@PathVariable Integer id){
		try {
			Notepad notepad =noteservice.get(id);
			return new ResponseEntity<Notepad>(notepad,HttpStatus.OK);
		}catch (NoSuchElementException e){
            return new ResponseEntity<Notepad>(HttpStatus.NOT_FOUND);
		}
	}
		@PostMapping("notepad")
	    public ResponseEntity<Notepad> add(@RequestBody Notepad notepad){
	        noteservice.save(notepad);
	        return new ResponseEntity<Notepad>(notepad,HttpStatus.CREATED);
	    }

	    @PutMapping("notepad")
	    public ResponseEntity<?> update(@RequestBody Notepad notepad) {
	        try {
	            Notepad existNotepad = noteservice.update(notepad);
	            noteservice.save(notepad);
	            return new ResponseEntity<>(HttpStatus.OK);
	        } catch (NoSuchElementException e) {
	            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
	        }
	    }

	    @DeleteMapping("notepad/{id}")
	    public void delete(@PathVariable Integer id) {
	        noteservice.delete(id);
	    }


	}

