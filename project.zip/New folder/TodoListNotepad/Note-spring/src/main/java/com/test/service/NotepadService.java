package com.test.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.test.model.Notepad;
import com.test.repository.NotepadRepository;

@Service
public class NotepadService {

	@Autowired
	private NotepadRepository notep;
	
	public List<Notepad> listAll(){
		return notep.findAll();
	}
	public Notepad get(int noteid) {
		return notep.findById(noteid).get();
	}
	public void save(Notepad notepad) {
		notep.save(notepad);
	}
	public Notepad update(Notepad notepad) {
		return notep.save(notepad);
	}
	public void delete(int noteid) {
		notep.deleteById(noteid);
	}
}
