package com.test.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Lob;

@Entity
public class Pad {

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int padid;
	private String heading;
	@Lob
	private String note;
	
	public Pad() {
		
	}
	public Pad(int padid,String heading,String note) {
		this.padid=padid;
		this.heading=heading;
		this.note=note;
		
	}
	public int getPadid() {
		return padid;
	}
	public void setPadid(int padid) {
		this.padid = padid;
	}
	public String getHeading() {
		return heading;
	}
	public void setHeading(String heading) {
		this.heading = heading;
	}
	public String getNote() {
		return note;
	}
	public void setNote(String note) {
		this.note = note;
	}
}
