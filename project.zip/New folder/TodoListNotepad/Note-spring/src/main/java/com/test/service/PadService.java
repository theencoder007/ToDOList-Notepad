package com.test.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.test.model.Pad;
import com.test.repository.PadRepository;

@Service
public class PadService {

	@Autowired
	private PadRepository padrepository;
	
	public List<Pad> listAll(){
		return padrepository.findAll();
	}
	public Pad get(int padid) {
		return padrepository.findById(padid).get();
	}
	public void save(Pad pad) {
		padrepository.save(pad);
	}
	public Pad update(Pad pad) {
		return padrepository.save(pad);
	}
	public void delete(int padid) {
		padrepository.deleteById(padid);
	}
}
