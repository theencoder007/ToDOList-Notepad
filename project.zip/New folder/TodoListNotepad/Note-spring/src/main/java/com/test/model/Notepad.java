package com.test.model;

import java.time.LocalDate;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;


@Entity
public class Notepad {

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int noteid;
	private String todo;
	private String priority;
	private LocalDate todayDate;
	public Notepad() {
		
	}
	public Notepad(int noteid,String todo,String priority,LocalDate todayDate) {
		this.noteid=noteid;
		this.todo=todo;
		this.priority=priority;
		this.todayDate=todayDate;
	}
	
	public int getNoteid() {
		return noteid;
	}
	public void setNoteid(int noteid) {
		this.noteid = noteid;
	}
	public String getTodo() {
		return todo;
	}
	public void setTodo(String todo) {
		this.todo = todo;
	}
	
	public String getPriority() {
		return priority;
	}
	public void setPriority(String priority) {
		this.priority = priority;
	}
	
	public LocalDate getTodayDate() {
		return todayDate;
	}
	public void setTodayDate(LocalDate todayDate) {
		this.todayDate = todayDate;
	}
}
