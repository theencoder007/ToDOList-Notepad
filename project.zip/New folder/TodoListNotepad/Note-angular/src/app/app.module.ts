import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { AboutComponent } from './about/about.component';
import { CreateNoteComponent } from './Notepad/create-note/create-note.component';
import { UpdateNoteComponent } from './Notepad/update-note/update-note.component';
import { NoteListComponent } from './Notepad/note-list/note-list.component';
import { HttpClientModule } from '@angular/common/http';
import { FormsModule } from '@angular/forms';
import { CreatePadComponent } from './pad/create-pad/create-pad.component';
import { PadListComponent } from './pad/pad-list/pad-list.component';
import { UpdatePadComponent } from './pad/update-pad/update-pad.component';
import { ShowNoteComponent } from './Notepad/show-note/show-note.component';
import { ShowComponent } from './pad/show/show.component';
import { RegistrationComponent } from './registration/registration.component';
import { LoginComponent } from './login/login.component';


@NgModule({
  declarations: [
    AppComponent,
    AboutComponent,
    CreateNoteComponent,
    UpdateNoteComponent,
    NoteListComponent,
    CreatePadComponent,
    PadListComponent,
    UpdatePadComponent,
    ShowNoteComponent,
    ShowComponent,
    RegistrationComponent,
    LoginComponent

  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
