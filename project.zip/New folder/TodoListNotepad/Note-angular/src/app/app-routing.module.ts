import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AboutComponent } from './about/about.component';
import { LoginComponent } from './login/login.component';
import { CreateNoteComponent } from './Notepad/create-note/create-note.component';
import { NoteListComponent } from './Notepad/note-list/note-list.component';
import { UpdateNoteComponent } from './Notepad/update-note/update-note.component';
import { CreatePadComponent } from './pad/create-pad/create-pad.component';
import { PadListComponent } from './pad/pad-list/pad-list.component';
import { UpdatePadComponent } from './pad/update-pad/update-pad.component';
import { RegistrationComponent } from './registration/registration.component';


const routes: Routes = [
  {path:'about',component:AboutComponent},

  {path:'login',component:LoginComponent},
  {path:'registration',component:RegistrationComponent},

  {path:'note-list',component:NoteListComponent},
  {path:'create-note',component:CreateNoteComponent},
  {path:'update-note/:id',component:UpdateNoteComponent},
  
  {path:'create-pad',component:CreatePadComponent},
  {path:'pad-list',component:PadListComponent},
  {path:'update-pad/:id',component:UpdatePadComponent},

  {path:'',redirectTo:'login',pathMatch:'full'}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
