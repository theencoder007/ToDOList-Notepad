import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Notepad } from '../model/notepad';

@Injectable({
  providedIn: 'root'
})

export class NotepadService {

  private baseUrl="http://localhost:8080/notepad";

  constructor(private httpClient: HttpClient) { }

  getNote(): Observable<Notepad[]>{
    return this.httpClient.get<Notepad[]>(`${this.baseUrl}`);
  }

  createNote(notepad:Notepad): Observable<Object>{
    return this.httpClient.post(`${this.baseUrl}`, notepad);
  }

  getNoteById(id: number): Observable<Notepad>{
    return this.httpClient.get<Notepad>(`${this.baseUrl}/${id}`);
  }

  updateNote(id: number, notepad: Notepad): Observable<Object>{
  return this.httpClient.put(`${this.baseUrl}`,notepad);
}

deleteNote(id: number): Observable<Object>{
  return this.httpClient.delete(`${this.baseUrl}/${id}`);
}

}