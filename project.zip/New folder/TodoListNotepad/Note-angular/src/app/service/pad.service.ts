import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Pad } from '../model/pad';

@Injectable({
  providedIn: 'root'
})

export class PadService {

  private baseUrl="http://localhost:8080/pad";

  constructor(private httpClient: HttpClient) { }

  getPad(): Observable<Pad[]>{
    return this.httpClient.get<Pad[]>(`${this.baseUrl}`);
  }

  createPad(pad:Pad): Observable<Object>{
    return this.httpClient.post(`${this.baseUrl}`, pad);
  }

  getPadById(id: number): Observable<Pad>{
    return this.httpClient.get<Pad>(`${this.baseUrl}/${id}`);
  }

  updatePad(id: number, pad: Pad): Observable<Object>{
  return this.httpClient.put(`${this.baseUrl}`,pad);
}

deletePad(id: number): Observable<Object>{
  return this.httpClient.delete(`${this.baseUrl}/${id}`);
}

}