export class Pad {

    padid: number;
    heading: string;
    note: string; 
  
  
  }
  