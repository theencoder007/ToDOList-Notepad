export class User {

  userId: number;
  userName: string;
  bname:String;
  password: string;



}
