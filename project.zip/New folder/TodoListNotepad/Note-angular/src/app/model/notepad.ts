export class Notepad {

  noteid: number;
  todo: string;
  priority:string;
  todayDate:String
  


}
