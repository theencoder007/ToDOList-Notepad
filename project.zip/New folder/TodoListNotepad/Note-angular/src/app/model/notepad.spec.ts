import { Notepad } from './notepad';

describe('Notepad', () => {
  it('should create an instance', () => {
    expect(new Notepad()).toBeTruthy();
  });
});
