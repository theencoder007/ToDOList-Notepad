import { Pad } from "./pad";

describe('Pad', () => {
  it('should create an instance', () => {
    expect(new Pad()).toBeTruthy();
  });
});
