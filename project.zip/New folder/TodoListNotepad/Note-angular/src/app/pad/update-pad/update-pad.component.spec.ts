import { ComponentFixture, TestBed } from '@angular/core/testing';

import { UpdatePadComponent } from './update-pad.component';

describe('UpdatePadComponent', () => {
  let component: UpdatePadComponent;
  let fixture: ComponentFixture<UpdatePadComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ UpdatePadComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(UpdatePadComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
