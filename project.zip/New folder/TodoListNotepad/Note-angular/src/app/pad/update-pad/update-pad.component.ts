import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Pad } from 'src/app/model/pad';
import { PadService } from 'src/app/service/pad.service';

@Component({
  selector: 'app-update-pad',
  templateUrl: './update-pad.component.html',
  styleUrls: ['./update-pad.component.css']
})
export class UpdatePadComponent implements OnInit {

  id: number;
  pad: Pad = new Pad();


  constructor(private padservice: PadService, private route: ActivatedRoute, private router:Router) { }

  ngOnInit(): void {
    this.id = this.route.snapshot.params['id'];
    this.padservice.getPadById(this.id).subscribe(
      data => {
        this.pad=data;
      }, error => console.log(error)
    );
  }

  savePad(){
    this.padservice.updatePad(this.id, this.pad).subscribe(data =>{
        this.goToPadList();
    }, error => console.log(error));
  }

  goToPadList(){
    this.router.navigate(['/pad-list'])
  }

}