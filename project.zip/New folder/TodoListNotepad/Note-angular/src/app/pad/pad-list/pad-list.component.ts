import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Pad } from 'src/app/model/pad';
import { PadService } from 'src/app/service/pad.service';

@Component({
  selector: 'app-pad-list',
  templateUrl: './pad-list.component.html',
  styleUrls: ['./pad-list.component.css']
})
export class PadListComponent implements OnInit {
  pads: Pad[];

  constructor(private padservice: PadService, private router: Router) { }

  ngOnInit(): void {
    this.getPad();
  }

  getPad(){
    this.padservice.getPad().subscribe(data => {
      this.pads = data;
      console.log(this.pads);
    });
  }

  updatePad(id: number){
    console.log(id);
    this.router.navigate(['/update-pad', id]);
  }


  deletePad(id: number){
    this.padservice.deletePad(id).subscribe(
      data => {
        console.log(data);
        this.getPad();
      }, error => {
        console.log("Not Delete")
      }
    )
  }
  logout(){

    localStorage.removeItem('userid');
    localStorage.removeItem('username');
    localStorage.removeItem('password');
    localStorage.removeItem('role');

    this.router.navigate(['/login']);

  }


}
