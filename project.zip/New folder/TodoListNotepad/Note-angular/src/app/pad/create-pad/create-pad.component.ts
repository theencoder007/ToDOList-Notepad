import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Pad } from 'src/app/model/pad';
import { PadService } from 'src/app/service/pad.service';

@Component({
  selector: 'app-create-pad',
  templateUrl: './create-pad.component.html',
  styleUrls: ['./create-pad.component.css']
})
export class CreatePadComponent implements OnInit {

  pad: Pad = new Pad();


  constructor(private padService: PadService, private router: Router) { }

  ngOnInit(): void {
  }

  savePad(){
    this.padService.createPad(this.pad).subscribe(data=>{
      console.log(data);
      this.goToPadList();
    }, error => console.log(error));
  }

  goToPadList(){
    this.router.navigate(['/pad-list']);
  }

}
