import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CreatePadComponent } from './create-pad.component';

describe('CreatePadComponent', () => {
  let component: CreatePadComponent;
  let fixture: ComponentFixture<CreatePadComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CreatePadComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(CreatePadComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
