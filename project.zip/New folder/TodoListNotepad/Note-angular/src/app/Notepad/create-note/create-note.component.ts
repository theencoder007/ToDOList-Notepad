import { Component, OnInit } from '@angular/core';
import { Notepad } from 'src/app/model/notepad';
import { Router } from '@angular/router';
import { NotepadService } from 'src/app/service/notepad.service';

@Component({
  selector: 'app-create-note',
  templateUrl: './create-note.component.html',
  styleUrls: ['./create-note.component.css']
})
export class CreateNoteComponent implements OnInit {

  notepad: Notepad = new Notepad();

  constructor(private notepadservice: NotepadService, private router: Router) { }

  ngOnInit(): void {
  }

  saveNote(){
    this.notepadservice.createNote(this.notepad).subscribe(data=>{
      console.log(data);
      this.goToNotepadList();
    }, error => console.log(error));
  }

  goToNotepadList(){
    this.router.navigate(['/note-list']);
  }

}