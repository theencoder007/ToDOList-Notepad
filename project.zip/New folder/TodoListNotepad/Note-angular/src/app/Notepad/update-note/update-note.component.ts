import { Component, OnInit } from '@angular/core';
import { Notepad } from 'src/app/model/notepad';
import { Router } from '@angular/router';
import { ActivatedRoute } from '@angular/router';
import { NotepadService } from 'src/app/service/notepad.service';

@Component({
  selector: 'app-update-note',
  templateUrl: './update-note.component.html',
  styleUrls: ['./update-note.component.css']
})
export class UpdateNoteComponent implements OnInit {

  id: number;
  notepads: Notepad = new Notepad();

  constructor(private notepadservice: NotepadService, private route: ActivatedRoute, private router: Router) { }

  ngOnInit(): void {
    this.id = this.route.snapshot.params['id'];
    this.notepadservice.getNoteById(this.id).subscribe(
      data => {
        this.notepads=data;
      }, error => console.log(error)
    );
  }

  saveNote(){
    this.notepadservice.updateNote(this.id, this.notepads).subscribe(data =>{
        this.goToNoteList();
    }, error => console.log(error));
  }

  goToNoteList(){
    this.router.navigate(['/note-list'])
  }

}
