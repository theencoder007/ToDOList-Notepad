import { Component, OnInit } from '@angular/core';
import { Notepad } from 'src/app/model/notepad';
import { NotepadService } from 'src/app/service/notepad.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-note-list',
  templateUrl: './note-list.component.html',
  styleUrls: ['./note-list.component.css']
})
export class NoteListComponent implements OnInit {
  notepads: Notepad[];
  constructor(private notepadservice: NotepadService, private router: Router) { }

  ngOnInit(): void {
    this.getNotes();
  }

  getNotes(){
    this.notepadservice.getNote().subscribe(data => {
      this.notepads = data;
      console.log(this.notepads);
    });
  }

  updateNote(id: number){
    console.log(id);
    this.router.navigate(['/update-note', id]);
  }

  deleteNote(id: number){
    this.notepadservice.deleteNote(id).subscribe(
      data => {
        console.log(data);
        this.getNotes();
      }, error => {
        console.log("Not Delete")
      }
    )
  }
  logout(){

    localStorage.removeItem('userid');
    localStorage.removeItem('username');
    localStorage.removeItem('password');
    localStorage.removeItem('role');

    this.router.navigate(['/login']);

  }


}
